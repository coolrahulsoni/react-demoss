import React, { Component } from 'react';

export default class ErrorBoundries extends React.Component{
    constructor(){
        super();
        this.state ={
            hasError : false
        }
    }

    componentDidCatch(err){
        alert("Error Occured....");
    }

    static getDerivedStateFromErro(){
            return {
                    hasError:true
            }
    }

    render(){
        if(this.state.hasError){
            return <div>the component is not avaialabel</div>
        }
        else {

           return <HomeComponent />
        }
    }
}

class HomeComponent extends React.Component{
    

    componentDidMount(){
        setTimeout(() => {
            throw new Error("Error Occured");
        }, 5000);
    }
    
    render(){
        return <div>Hello demo</div>;
    }

   
}
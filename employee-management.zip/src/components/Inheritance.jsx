import React, { Component } from 'react';

class Inheritiance extends React.Component{
    alertUser(){
        alert('hello world');
    }

    constructor(){
        super();
        this.state={
            name : "Rahul"
        }
    }

    render(){
        return <div>Hello deiv</div>
    }
}

export default class ChildComponent extends Inheritiance{
    render(){
        return (
            <>
            hello {this.state.name}
            <input type="button" onClick={this.alertUser}/>
        </>
            )
    }
}
import React, { Component } from 'react';

export default class LifeCycleEvents extends React.Component {

  

    constructor(props){
        setTimeout(() => {
            alert('settimeout');
        }, 0);
        super(props);
        this.state ={
            name: "Rahul"
        }
        alert('constructor');
        console.log(this.props);
    }


/******
 * 
 * if we want to use this.props in state constructor we have to implement it in getDerivedStateFromProps events
 * 
 * 
 * 
*/

    static getDerivedStateFromProps(props){
        alert('getDerivedStateFromProps');
        return{
            age:props.age
        }
    }

    componentWillMount(){
        alert('componentg will mount')
    }

    render(){
        alert('rendered');
        return (
            <div>
                <strong>
                 user name : {this.state.name}
                </strong>
            </div>
        )
    }

    componentDidMount(){

        setTimeout(() => {
            this.setState({
                name:"soni",
            })
        }, 10000);

        
       

        alert('componentg did mount')
    }


    shouldComponentUpdate(){
        return true;
    }

    componentDidUpdate(){
        alert('comonent did udate');
    }

}
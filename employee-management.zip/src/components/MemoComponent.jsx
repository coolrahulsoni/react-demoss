import React, { Component } from 'react';

function MemoComponent(){
    return <div>Hello world</div>
}

export default React.memo(MemoComponent);
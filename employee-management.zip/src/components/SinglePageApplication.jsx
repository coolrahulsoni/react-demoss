import React, { Component } from 'react';
import { BrowserRouter ,Route , Link, Switch } from "react-router-dom";

export default class SinglePageApplication extends React.Component {
    render(){
        return (
            <BrowserRouter>
                <HeaderComponent />

                <div style={{"height":"500px","width":"100%","border":"1px solid #000"}}>
                    <Link to="home">Home</Link>
                    <Link to="help">Help</Link>
                    <Link to="about/10/mayank/md">About</Link>
{/* 

***********


navlink used for change classes when changing route for for highlighted  with "activeClassName"



we can use render instead of component if we want to pass some props in component




*/}
                    <Switch>
                        <Route exact path="/about/:id/:name/:designation" component={ AboutComponent } />
                        <Route exact path="/help" component={ HelpComponent } />
                        <Route exact path="/" component={ HomeComponent } />
                        <Route component={ PageNotFound } />
                    </Switch>


                </div>

                <FooterComponent />    
            </BrowserRouter>
        )
    }
}

function HeaderComponent(){
    return <div>this is header</div>
}

function FooterComponent(){
    return <div>this is footer</div>
}

function HomeComponent(){
    return <div>this is Home</div>
}

function AboutComponent(){
    return <div>this is About</div>
}

function HelpComponent(props){
    debugger;
    return <div>this is Help</div>
}
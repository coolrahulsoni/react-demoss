import React, { Component } from 'react';

export default class UnmountingChildComponent extends React.Component{
    constructor(){
        super();
        this.state ={
            name : "Rahul"
        }
    }

    componentDidMount(){
        setTimeout(() => {
            this.setState({
                name:'Soni'
            })
        }, 3000);
    }


    render(){
        return (
            <>
            { this.state.name === "Rahul"  && <span><ChildComponent /></span> }
            { this.state.name !== "Rahul"  && <span><ChildComponent /></span> }
           </>
        )
    }
}

class ChildComponent extends React.Component{
    render(){
        return (
            <div>Hello bye</div>
        )
    }

    componentWillUnmount(){
        alert('component unmounted');
    }
}
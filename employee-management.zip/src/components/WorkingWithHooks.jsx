import React, { useState,useEffect } from 'react';

export default function WorkingWithHooks(){
    const[name,setName] = useState("Rahul");
/* const use for getter and setter of value in es6  */

function updateName(){
    setName("soni");
}


/* use effect is use to take is comppnent is redering or hooks

router.prefetch will be called after page is loaded 


rs.js js used rx.observable nd rx.observalbe create amd oberver.create willl change all the data assosicaited with there subscriber function 

*/

useEffect(()=>{
    console.log('component added');
})

return (
       <>
        <div>{name}</div><br/>
        <input type="button" value="click" onClick={updateName}/>
        <input type="button" value="click2" onClick={()=> setName('Rahul')}/>
      </>
        )

}
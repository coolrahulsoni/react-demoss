import React from 'react'

export default class ChildStateProportion extends React.Component{

    constructor(){
        super();
        this.state ={
            name:"Rahul",
            age:"20",
            designation : "1111"
        }

        setTimeout(() => {
            this.setState ({
                name:"SOni",
                age:"28"
            })
        }, 4000);
    }

    updateValues= () => {
        this.setState({
            age:this.state.age + 1 ,
            xyz: 1
        })
    }


    render(){
        return(
            <div id="mainID" onClick={this.detectTarget}>
                <strong>
                    parent component
                   <ChildComponent name={this.state.name}  age={this.state.age}/><br/><hr/><br/>
                </strong>
            </div>
        )
    }
}


class ChildComponent extends React.Component{
    constructor (){
        super();
        this.state={
            age : 25
        }
    }
    render(){
    return(
        <div id="mainID">
            <strong>
               name : {this.props.name} ,
                <OtherChildComponent age={this.props.age} updateAge= {this.updateAge} />
               
            </strong>
        </div>
    )
    }
}

function OtherChildComponent(props){
    return(
        <div id="mainID">
            <strong>
              age is :{props.age}
               <input type="button" onClick={props.updateValues} value="update value" /> 
            </strong>
        </div>
    )
}
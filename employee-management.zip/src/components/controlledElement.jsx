import React, { Component } from 'react';
import { extname } from 'path';



export default class controlledElement extends React.Component{
constructor(){
    super();
    this.state ={
        name:"rahul"
    }
}

getUpdatedValue = (event) => {
    this.setState ({
        name:event.target.value
    })
  
this.refs.myUncontrolledElement.value = "ddddummmmmyyyyy";

this.refs.myUncontrolledElement.style.color = "red";

}

render(){
    return (
        <div>
            <div>
                <input type="text" value={this.state.name} onChange ={this.getUpdatedValue }/> <br />
                <input type="text" ref="myUncontrolledElement"/>
            </div>
        </div>
    )
}

} 
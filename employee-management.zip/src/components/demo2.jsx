import React from 'react'



export default function Demo2(props){
    var newName = "Rahul SOni"
     var newName2 = function (){
         return newName;
     }
 
 var styleProps = {graycolor: {"color":props.color},redcolor:{"color":"red"} };
 
 
     var color = props.color; 
     return (
        <div><div className="DemoDiv"><strong style={{"color":color,"fontSize":"25px"}}>My Name is : {props.name}  My Age is:{props.age} </strong></div>
          <div style={styleProps.redcolor}>{newName2()}</div>
        </div>    
  )
 }
 
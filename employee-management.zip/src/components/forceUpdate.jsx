import React, { Component } from 'react';

export default class ForceUpdate extends React.Component {
constructor(){
    super();
    this.state ={
        name:"Mayank"
    }
}

updateData = () =>{
    this.state.name = "Soni";
    this.forceUpdate();
}

render(){
if(this.state.name !== "Mayank"){
    return null;
}

    return(
        <div>
           {this.state.name === "Mayank" && ( <div> name : {this.state.name} <br /> </div> )}
          <input type="button" onlClick={this.updateData} value="update name" />
        </div>
    )
}
}

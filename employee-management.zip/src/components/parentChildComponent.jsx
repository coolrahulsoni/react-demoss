import React from 'react';

export  function ParentChildComponent(props){
    return (
        <div>
            <h1>
                This is the parent COmponent
            </h1>
            <HeaderComponent/>
            <ContentComponent name={props.name} />
            <FooterComponent/>
        </div>
    )
}

function HeaderComponent(props){
    return <h1>Header</h1>
}

function ContentComponent(props){
    return <h1>{props.name}</h1>
}

function FooterComponent(props){
    return <h1>footer</h1>
}
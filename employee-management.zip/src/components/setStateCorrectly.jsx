import React from "react";

export default class SetStateCorrectly extends React.Component{
    constructor(){
        super();
        this.state = {
            counter : 1
        }
      
    }

    updateCounter = () => {
       this.setState((state,props) => {
           return {
               counter : state.counter + 1
           }
       })
        
        
       this.setState((state) => {
           return {
               counter : state.counter + 1
           }
       })
        
        
      
    }
/*********  this wil not run without callback function
    updateCounter = () => {
        debugger;
        this.setState({
            counter:this.state.counter + 1 
        }

         this.setState({
            counter:this.state.counter + 1 
        }) 
      
    }
******************************/

    render(){
        return(
            <div>
                <strong>
                    counter value : {this.state.counter}
                    <button type="button" value="increment counter" onClick={this.updateCounter}> Plus 1 </button>
                </strong>
            </div>
        )
    }
}
import React, { Component } from 'react';
import { throwStatement } from '@babel/types';

export default class SimpleClassComponent extends React.Component {

    constructor() {
        super();
        this.state = {
            componentData: "Random Data",
            timer: new Date().toLocaleTimeString(),
        }

/****  context in js closure    ***** context means who is the caller here bind is called by simple class object  if we put nrml setInterbal than window will be caller or context 
 * 
 * 
 * if we use class component we have to use bind or arrow function for context 
 * 
 * react use only this  force update ; state update ; props update for update data
 * 
 * 
 *
        setInterval(function() {
            this.setState({
                timer: new Date().toLocaleTimeString(),
            })
        }.bind(this), 1000);
*
*
*
*
 */

        setInterval(() {
            this.setState({
                timer: new Date().toLocaleTimeString(),
            })
        }, 1000);
    }
    render() {
        return (
            <div>
                <strong>
                    Current Time : {this.state.timer}
                </strong>
            </div>
        )
    }
}
import React from 'react';

export default class StateAreMerged extends React.Component{

    constructor(){
        super();
        this.state ={
            name:"Rahul",
            age:"20",
            designation : "1111"
        }
    }

    updateValues= () => {
        this.setState({
            age:this.state.age + 1 ,
            xyz: 1
        })
    }


    render(){
        return(
            <div>
                <strong>
                    user Age is : {this.state.name} , XYZ : {this.state.xyz}
                    user Age is : {this.state.age}
                    counter value : {this.state.counter}
                    <button type="button" value="increment counter" onClick={this.updateValues}> Update </button>
                </strong>
            </div>
        )
    }
}
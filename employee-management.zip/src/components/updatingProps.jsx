import React from 'react';

export default function UpdatingProps(props){
    //    props.name = "Data";
    props.details.name = "Rahul"
    return (
        <div>
            the name is {props.details.name}
        </div>
    )
}
import  React from 'react';

export default function WithoutJsx(){
    return React.createElement("div",{},
    React.createElement("div",{},React.createElement("strong",{},"hello world")));
}
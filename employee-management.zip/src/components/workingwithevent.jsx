import React from 'react';

export default class WorkingwithEvent extends React.Component{

    constructor(){
        super();
        this.state ={
            name:"Rahul",
            age:"20",
            designation : "1111"
        }
    }

    updateValues= (event) => {
        this.setState({
            age:this.state.age + 1 ,
            xyz: 1
        })
    }

/*****************
 * 
 * bind can be done by  adding this line in constructor 
 * 
 * 
 *  this.updateName = this.updateName.bind(this);
 * 
 * and this constructor is optimize way and most performance way for binding because only one time is binding for a fucnton not for every time .
 *  


 arrow function is not optimize way arrow finction bind function to object not on prototype 


*/

    updateName() {
        this.setState({
            name:this.state.name + "xyz"
           
        })
    }

    detectTarget = (event) =>{
        debugger;
        alert("target is : " + event.target.id);
    }

    render(){
        return(
            <div id="parent" onclick={this.detectTarget}>
                <strong>
                   <span id="name">user name is : {this.state.name} , XYZ : {this.state.xyz}</span> 
                    <span id="age">user Age is : {this.state.age}</span> 
                    <span id="counter">  counter value : {this.state.counter}</span> 
                    <button type="button" value="increment counter" onClick={this.updateValues}> Update </button>
                    <button type="button" value="increment counter" onClick={this.updateName.bind(this)}> Update name </button>
                </strong>
            </div>
        )
    }
}
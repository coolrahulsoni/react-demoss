import React, { Component } from 'react';
import axios from "axios"



export default class Workingwithfragment extends React.Component{
    constructor() {
        super();
        fetch("http://dummy.restapiexample.com/api/v1/employees").then(response  =>  {
            return response.json()

        }).then((reponseData) => {
            this.setState({
                empArr :responseData
            })
        })
        /* axios.get("https://jsonplaceholder.typicode.com/todos/1").then((responseData) => {
            debugger;
        } ) */

        
    }

    addEmployee =  () => {
        alert('user added')

        this.setState({
            empArr: this.state.empArr.push()
        })

       
    }

    shouldComponentUpdate(){
        return true;
    }
    
render(){
    return (
        <div>

            {this.state.empArr.map((employee) => {
                return (
                    <div>
                        Name : <strong> {employee.employee_id }</strong>
                        Age : <strong> {employee.age }</strong>
                        Designation : <strong> {employee.designation }</strong>
                    </div>
                )
            })
                }
                <div>
                    <p>
                        <label> Enter Name Employee Name :</label>
                        <input type="button" value="add employee" onClick={this.addEmployee} />
                    </p>
                </div>
        </div>
    )
            }
}
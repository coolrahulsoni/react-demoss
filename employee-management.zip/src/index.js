import ReactDOM from "react-dom";
import React from "react";
import Demo2 from "./components/demo2";
//import WithoutJsx from "./components/withoutJsx";
//import  UpdatingProps from "./components/updatingProps";
import  SimpleClassComponent from "./components/simpleClassComponent";
import   "./Style.css";

var details = {
    name :"Rahul Soni",
    age : "26"
}

    ReactDOM.render((
        
        <div><Demo2 name="Soni" age="20" color="blue" /> <br /> <Demo2 name="Rahul" age="26"/></div>
    )
    ,document.getElementById('root'))
    ReactDOM.render((
        <div>
        {/* <div>{details.name}</div> */}
        <div><SimpleClassComponent details={details} age="20" color="blue"/></div>
        </div>
    )
    ,document.getElementById('root'))

